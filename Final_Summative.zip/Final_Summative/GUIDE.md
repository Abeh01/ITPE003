# CANDY STORE
    CYS:    BIT35
    Name:   Candido, Abigail F.
            Fujii, Mearie E.
            Rosales, Angelica J.

-----------------------------------------------------------------------

## FEATURES
    * This Candy Store System is designed for the customers (users) to order candy products online.
    * There would be a Registration and Login Server (has database) to distinguish users from admin.
    * In the Admin Dashboard View, they can add, edit, and delete products (menu).
    * In the Customer (User) Dashboard View, they can browse through the menu added by the Admin.
    * In the Cart View of the User, the products they intended to buy will be shown and they need to fill in other details so they can checkout.
    * In the Admin Orders View, they can view all the orders of the User.

-----------------------------------------------------------------------

## STRUCTURE
    Final_Summative/
    │
    ├── models/
    │ ├── ProductItems.js       # Schema for products added by admin
    │ ├── CartItems.js          # Schema for cart items selected by users
    │ ├── Orders.js             # Schema for completed orders with user details
    │ └── User.js               # Schema for login credentials
    │
    ├── routes/
    │ ├── authRoutes.js         # Handles user registration & login routes
    │ ├── userRoutes.js         # Handles user dashboard, cart, and checkout
    │ ├── adminRoutes.js        # Handles admin features (menu & orders)
    │ └── orderRoutes.js        # Order placement & retrieval routes
    │
    ├── views/
    │ ├── Registration.ejs      # Registration page
    │ ├── Login.ejs             # Login page
    │ ├── UserDashboard.ejs     # Customer dashboard view
    │ ├── UserCart.ejs          # Customer cart view
    │ ├── AdminDashboard.ejs    # Admin menu management view
    │ ├── AdminAddCandy.ejs     # Admin menu management view
    │ └── AdminOrders.ejs       # Admin order list view
    │
    ├── public/                 
    │ ├── uploads/
    │ ├── style/
    │ └── js/
    │  ├── adminDashboard.js
    │  ├── userDashboard.js
    │  ├── userCart.js
    │  ├── adminOrder.js
    │  ├── login.js
    │  └── register.js
    |
    ├── node_modules/           # Project dependencies
    ├── GUIDE.md                # This guide file
    ├── package.json            # Project configuration and dependencies
    ├── package-lock.json       # Locked dependency versions
    └── server.js               # Main Express server file

-----------------------------------------------------------------------

## TASK DISTRIBUTION

### Candido (Back-End)
    JavaScript for .ejs Files
        * login.js
        * register.js 
        * adminDashboard.js
        * adminOrder.js
    Models
        * ProductItems.js
        * User.js
        * Orders.js 
    Routes
        * authRoutes.js
        * userRoutes.js
        * adminRoutes.js
        * orderRoutes.js
    Main Server
        * server.js

### Fujii (Front-End + Design)
    Views
        * Registration.ejs
        * Login.ejs
        * UserDasboard.ejs       
        * UserCart.ejs
        * AdminDashboard.ejs
        * AdminOrders.ejs
    CSS
        * style.cs

### Rosales (Back-End + Design)
    JavaScript for .ejs Files
        * userDashboard.js 
        * userCart.js
        * adminDashboard.js
    Models
        * ProductItems.js
        * CartItems.js
        * Orders.js 
    Routes
        * userRoutes.js
        * adminRoutes.js
        * orderRoutes.js
    Main Server
        * server.js
    CSS
        * style.cs

-----------------------------------------------------------------------

## EXTRA INFORMATION + UPDATE

### Models
    [✅] ProductItems.js         # Data Schema of Products or Menu added by the Admin
    [ ] CartItems.js            # Data Schema of Cart Items from the menu chosen by the User
    [ ] Orders.js               # Data Schema of Complete Order (cart items & user information) of the User
    [✅] User.js                # Data Schema of User Registration

### Routes
    [✅] authRoutes.js          # Handles all authentication-related routes (login, registration, and their views) 
                                    └─ AND If credentials are valid, it redirects to UserDashboard.ejs (/user/dashboard) or AdminDashboard.ejs (/admin/dashboard)
    [✅] userRoutes.js          # Renders the page to UserDashboard.ejs (/user/dashboard)
    [✅] adminRoutes.js         # Renders the page to UserDashboard.ejs (/user/dashboard)

### Views
    [✅] Registration.ejs
    [✅] Login.ejs
    [✅] UserDasboard.ejs       
    [ ] UserCart.ejs
    [✅] AdminDashboard.ejs
    [ ] AdminAddCandy.ejs
    [ ] AdminOrders.ejs

## Individual JavaScript (public .js files)
    [✅] login.js               # Handles the Login.ejs 
                                    └─ AND Sends login request to authRoutes.js (/auth/login) 
    [✅] register.js            # Handles the Registration.ejs
    [✅] adminDashboard.js      # Handles the AdminDashboard.ejs
    [ ] userDashboard.js        # Handles the UserDashboard.ejs
    [ ] userCart.js             # Handles the UserCart.ejs
    [ ] adminOrder.js           # Handles the AdminOrder.ejs