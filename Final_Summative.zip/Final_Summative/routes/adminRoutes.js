// routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const ProductItem = require('../models/ProductItem');
const Order = require('../models/Order'); // <-- Import Order model

// Setup Multer for file upload
const storage = multer.diskStorage({
  destination: './public/uploads',
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

const methodOverride = require('method-override');
router.use(methodOverride('_method'));  // <-- Add this line if not already present

// Show Edit Candy Page
router.get('/editcandy/:id', async (req, res) => {
  try {
    const candy = await ProductItem.findById(req.params.id);
    if (!candy) return res.status(404).send('Candy not found');
    res.render('AdminEditCandy', { candy });
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to load edit page');
  }
});

// Update Candy (Edit)
router.put('/products/:id', upload.single('picture'), async (req, res) => {
  try {
    const { name, description, price, quantity } = req.body;
    const updateData = { name, description, price, quantity };

    if (req.file) {
      updateData.picture = req.file.filename;  // If new image uploaded
    }

    await ProductItem.findByIdAndUpdate(req.params.id, updateData);
    res.redirect('/admin/dashboard');
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to update product');
  }
});


// Show Add Candy Page
router.get('/addcandy', (req, res) => res.render('AdminAddCandy'));

// Add candy product
router.post('/products', upload.single('picture'), async (req, res) => {
  try {
    const { name, description, price, quantity } = req.body;
    const newItem = new ProductItem({
      name,
      description,
      price,
      quantity,
      picture: req.file.filename
    });
    await newItem.save();
    res.redirect('/admin/dashboard');
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to add product');
  }
});

// Get all items
router.get('/products', async (req, res) => {
  const items = await ProductItem.find();
  res.json(items);
});

// Delete product
router.delete('/products/:id', async (req, res) => {
  try {
    await ProductItem.findByIdAndDelete(req.params.id);
    res.json({ message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Delete failed' });
  }
});

// ✅ Get all orders
router.get('/orders', async (req, res) => {
  try {
    const orders = await Order.find();
    res.render('AdminOrders', { orders });
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to load orders');
  }
});

// ✅ Update order status
router.post('/orders/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    await Order.findByIdAndUpdate(req.params.id, { status });
    res.redirect('/admin/orders');
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to update status');
  }
});

// Admin Logout
router.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Logout error:', err);
      return res.status(500).send('Failed to log out');
    }
    res.redirect('/auth/login'); // Redirect to login after logout
  });
});

module.exports = router;
