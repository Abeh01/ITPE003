const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Show Registration
router.get('/register', (req, res) => res.render('Registration'));

// Show Login
router.get('/login', (req, res) => res.render('Login'));

// Register User
router.post('/register', async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.status(201).json({ message: 'User registered.' });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: 'Registration failed.' });
  }
});

// ✅ Login with Admin check
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  // ✅ Admin check
  if (username === 'admin' && password === 'admin123') {
    req.session.userId = 'admin';
    return res.status(200).json({ message: 'Admin login successful', redirect: '/admin/dashboard' });
  }

  // 🔍 MongoDB user check
  try {
    const user = await User.findOne({ username });

    if (!user || user.password !== password) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    req.session.userId = user._id;
    res.status(200).json({ message: 'User login successful', redirect: '/user/dashboard' });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
