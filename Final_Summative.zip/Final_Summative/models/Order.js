// models/Order.js
const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  items: [
    {
      name: String,
      price: Number,
      quantity: Number,
      total: Number
    }
  ],
  totalBill: Number,
  address: String,
  phoneNumber: String,

  // 👇 New field for user info
  user: {
    firstName: String,
    lastName: String,
    username: String,
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  },

  status: {
    type: String,
    default: 'Processing',
    enum: ['Processing', 'Shipped', 'Out for Delivery', 'Delivered']
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Order', orderSchema);
