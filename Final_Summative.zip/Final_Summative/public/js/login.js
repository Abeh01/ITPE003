document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const data = {
    username: document.getElementById('username').value.trim(),
    password: document.getElementById('password').value.trim()
  };

  try {
    const res = await fetch('/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    const result = await res.json();

    if (res.ok) {
      alert('Login successful!');
      window.location.href = result.redirect; // Handle role-based redirect
    } else {
      alert(result.error || 'Login failed.');
    }
  } catch (err) {
    alert('Error logging in.');
    console.error(err);
  }
});
