// public/js/adminDashboard.js

// Load candies on page load
document.addEventListener('DOMContentLoaded', loadCandies);

async function loadCandies() {
  const res = await fetch('/admin/products');
  const candies = await res.json();

  const table = document.getElementById('candyTableBody');
  table.innerHTML = '';

  candies.forEach(candy => {
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${candy._id}</td>
        <td>${candy.name}</td>
        <td>${candy.description}</td>
        <td>${candy.price}</td>
        <td><img src="/uploads/${candy.picture}" width="60" /></td>
        <td>
            <button onclick="deleteCandy('${candy._id}')">Delete</button>
        </td>
        `;

    table.appendChild(row);
  });
}

async function deleteCandy(id) {
  if (!confirm('Delete this candy?')) return;

  try {
    await fetch(`/admin/products/${id}`, { method: 'DELETE' });
    loadCandies();
  } catch (err) {
    alert('Failed to delete candy');
    console.error(err);
  }
}
