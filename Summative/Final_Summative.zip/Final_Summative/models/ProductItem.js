// models/ProductItem.js
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: String,
  description: String,
  price: Number,
  picture: String
});

module.exports = mongoose.model('ProductItem', productSchema);
