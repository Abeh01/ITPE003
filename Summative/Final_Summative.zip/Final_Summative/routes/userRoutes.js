const express = require('express');
const router = express.Router();
const User = require('../models/User');
const ProductItem = require('../models/ProductItem');
const Order = require('../models/Order');

let cart = []; // In-memory cart – temporary solution

// GET User Dashboard
router.get('/dashboard', async (req, res) => {
  try {
    const items = await ProductItem.find();
    res.render('UserDashboard', {
      items,
      message: req.session.message || null
    });
    req.session.message = null; // Clear message after showing
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// POST Add to Cart
router.post('/cart/add', (req, res) => {
  const { productId, name, price, quantity } = req.body;

  const qty = parseInt(quantity);
  const item = cart.find(i => i.productId === productId);
  if (item) {
    item.quantity += qty;
    item.total = item.price * item.quantity;
  } else {
    cart.push({
      productId,
      name,
      price: parseFloat(price),
      quantity: qty,
      total: parseFloat(price) * qty,
    });
  }

  // ✅ Set message in session
  req.session.message = 'Item added to cart!';
  res.redirect('/user/dashboard');
});

// GET Cart Page (Fixed to pass user object)
router.get('/cart', async (req, res) => {
  try {
    const userId = req.session.userId;
    if (!userId) {
      return res.redirect('/auth/login'); // Redirect if no user session
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).send('User not found');
    }

    const totalBill = cart.reduce((sum, item) => sum + item.total, 0);

    res.render('UserCart', { user, cart, totalBill });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
});

// POST Update Quantity
router.post('/cart/update', (req, res) => {
  const { productId, quantity } = req.body;
  const qty = parseInt(quantity);

  const item = cart.find(i => i.productId === productId);
  if (item) {
    if (qty <= 0) {
      cart = cart.filter(i => i.productId !== productId); // Remove if qty is 0
    } else {
      item.quantity = qty;
      item.total = item.price * qty;
    }
  }
  res.sendStatus(200); // AJAX-friendly response
});


// POST Remove Item
router.post('/cart/remove', (req, res) => {
  const { productId } = req.body;
  cart = cart.filter(i => i.productId !== productId);
  res.redirect('/user/cart');
});

// POST Checkout
router.post('/cart/checkout', async (req, res) => {
  const { address, phone } = req.body;
  const totalBill = cart.reduce((sum, item) => sum + item.total, 0);

  try {
    const user = await User.findById(req.session.userId);

    const order = new Order({
      items: cart,
      totalBill,
      address,
      phoneNumber: phone,
      user: {
        firstName: user.firstName,
        lastName: user.lastName,
        username: user.username,
        userId: user._id
      }
    });

    await order.save();
    cart = [];

    const items = await ProductItem.find();
    res.render('UserDashboard', { items, message: 'Order placed successfully!' });
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to place order.');
  }
});

// User Logout
router.get('/logout', (req, res) => {
  // Clear session and in-memory cart
  cart = [];

  req.session.destroy(err => {
    if (err) {
      console.error('Logout error:', err);
      return res.status(500).send('Failed to log out');
    }

    res.clearCookie('connect.sid'); // Optional: clear session cookie
    res.redirect('/auth/login');    // Redirect to login page
  });
});

module.exports = router;