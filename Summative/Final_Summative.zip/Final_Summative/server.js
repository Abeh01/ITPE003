// 📦 Import required modules
const express = require('express');                             // Web framework for routing and middleware
const mongoose = require('mongoose');                           // MongoDB ODM for interacting with the database
const path = require('path');                                   // Node.js utility for handling file paths
const session = require('express-session');                     // Middleware for managing user sessions
const dotenv = require('dotenv');                               // Load environment variables from .env file

dotenv.config();                                                // 📄 Load .env configuration (e.g., DB URI, port)

const app = express();                                          // Create an Express app instance
const PORT = process.env.PORT || 3000;                          // Use environment PORT or default to 3000

const methodOverride = require('method-override');
app.use(methodOverride('_method'));

// 🔗 Connect to MongoDB
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/CandyStore', {
  useNewUrlParser: true,                                        // Avoid deprecation warning
  useUnifiedTopology: true                                      // Use new server discovery and monitoring engine
})
.then(() => console.log('✅ MongoDB connected'))                // Success log
.catch(console.error);                                          // Error log

// ⚙️ Middleware Setup
app.use(express.json());                                        // Parse incoming JSON requests
app.use(express.urlencoded({ extended: true }));                // Parse URL-encoded form data
app.use(express.static(path.join(__dirname, 'public')));        // Serve static files (CSS, JS, images, etc.)

// 🧩 View Engine
app.set('view engine', 'ejs');                                  // Set EJS as the template/view engine
app.set('views', path.join(__dirname, 'views'));                // Set the views folder path

// 🔐 Sessions
app.use(session({
  secret: 'candysecret',                                        // Secret key for session encryption (should be stored securely)
  resave: false,                                                // Don't save session if unmodified
  saveUninitialized: true                                       // Save new sessions even if they haven't been
}));

// 🚪 Mount Routes
const authRoutes = require('./routes/authRoutes');              // Handles login and registration
const userRoutes = require('./routes/userRoutes');              // Handles user dashboard
const adminRoutes = require('./routes/adminRoutes');

app.use('/auth', authRoutes);                                   // Mount auth routes at /auth (e.g., /auth/login)
app.use('/user', userRoutes);                                   // Mount user routes at /user (e.g., /user/dashboard)
app.use('/admin', adminRoutes);

// 🏠 Root redirect
app.get('/', (req, res) => res.redirect('/auth/login'));        // Redirect root to login page

// 🛠 Admin dashboard (session-guarded)
app.get('/admin/dashboard', (req, res) => {
  if (req.session.userId !== 'admin') return res.status(403).send('Access denied');
  res.render('AdminDashboard');                                 // Render the admin dashboard view
});

// ❌ Remove the old /user/dashboard definition here to avoid conflict

// 🚀 Start the server
app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));
