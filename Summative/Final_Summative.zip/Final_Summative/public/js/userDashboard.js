document.addEventListener('DOMContentLoaded', () => {
  // Product Quantity Selector (Dashboard Page)
  document.querySelectorAll('.quantity-form').forEach(form => {
    const decreaseBtn = form.querySelector('.decrease');
    const increaseBtn = form.querySelector('.increase');
    const display = form.querySelector('.quantity-display');
    const hiddenInput = form.querySelector('.quantity-input');

    let quantity = parseInt(hiddenInput.value) || 1;

    decreaseBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (quantity > 1) {
        quantity--;
        updateDisplay();
      }
    });

    increaseBtn.addEventListener('click', (e) => {
      e.preventDefault();
      quantity++;
      updateDisplay();
    });

    function updateDisplay() {
      display.textContent = quantity;
      hiddenInput.value = quantity;
    }
  });

  // Cart Quantity Adjustment (Cart Page)
  document.querySelectorAll('.cart-row').forEach(row => {
    const productId = row.dataset.productId;
    const decreaseBtn = row.querySelector('.qty-decrease');
    const increaseBtn = row.querySelector('.qty-increase');
    const quantityDisplay = row.querySelector('.quantity-display');
    const itemPrice = parseFloat(row.querySelector('.item-price').textContent.replace('₱', '')) || 0;
    const itemTotal = row.querySelector('.item-total');

    let quantity = parseInt(quantityDisplay.textContent);

    if (decreaseBtn && increaseBtn) {
      decreaseBtn.addEventListener('click', () => {
        if (quantity > 1) {
          quantity--;
          updateQuantity();
        } else {
          // Remove item when quantity hits 0
          row.remove();
          updateTotalBill();
          removeItemFromServer(productId);
          checkIfCartIsEmpty();
        }
      });

      increaseBtn.addEventListener('click', () => {
        quantity++;
        updateQuantity();
      });
    }

    function updateQuantity() {
      if (quantity <= 0) {
        sendQuantityUpdateToServer(productId, quantity);
        row.remove(); // Remove the row from DOM
        updateTotalBill();
        return; // Stop further execution
      }

      quantityDisplay.textContent = quantity;
      const totalPrice = (itemPrice * quantity).toFixed(2);
      itemTotal.textContent = `₱${totalPrice}`;
      updateTotalBill();
      sendQuantityUpdateToServer(productId, quantity);
    }

  });

  function updateTotalBill() {
    let total = 0;
    document.querySelectorAll('.item-total').forEach(totalEl => {
      const amount = parseFloat(totalEl.textContent.replace('₱', '')) || 0;
      total += amount;
    });
    const totalBillEl = document.getElementById('totalBill');
    if (totalBillEl) {
      totalBillEl.textContent = total.toFixed(2);
    }
  }

  function sendQuantityUpdateToServer(productId, quantity) {
    fetch('/user/cart/update', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ productId, quantity })
    }).catch(err => {
      console.error('Error updating quantity:', err);
    });
  }

  function removeItemFromServer(productId) {
    fetch('/user/cart/remove', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ productId })
    }).catch(err => {
      console.error('Error removing item:', err);
    });
  }

  function checkIfCartIsEmpty() {
    if (document.querySelectorAll('.cart-row').length === 0) {
      const cartContainer = document.querySelector('.cart-container');
      if (cartContainer) {
        cartContainer.innerHTML = '<p class="empty-cart">Your cart is empty.</p>';
      }
    }
  }

  function checkIfCartIsEmpty() {
    if (document.querySelectorAll('.cart-row').length === 0) {
      const cartContainer = document.querySelector('.cart-container');
      if (cartContainer) cartContainer.remove();

      const emptyCartMsg = document.createElement('p');
      emptyCartMsg.className = 'empty-cart';
      emptyCartMsg.textContent = 'Your cart is empty.';
      document.body.appendChild(emptyCartMsg);
    }
  }

  // Call after removing row
  row.remove();
  updateTotalBill();
  checkIfCartIsEmpty();


  // Optional Backend Flash Message Alert
  if (window.showAlertMessage) {
    alert(window.showAlertMessage);
  }
});