document.getElementById('registrationForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const data = {
    firstName: document.getElementById('firstName').value.trim(),
    lastName: document.getElementById('lastName').value.trim(),
    email: document.getElementById('email').value.trim(),
    phoneNumber: document.getElementById('phoneNumber').value.trim(),
    username: document.getElementById('username').value.trim(),
    password: document.getElementById('password').value.trim(),
  };

  try {
    const res = await fetch('/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    const result = await res.json();
    if (res.ok) {
      alert('Registration successful!');
      window.location.href = '/auth/login';
    } else {
      alert(result.error || 'Registration failed.');
    }
  } catch (err) {
    alert('Error registering user.');
    console.error(err);
  }
});
