const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

// Import models
const MenuItem = require('./models/menuitem');
const Order = require('./models/Order');

const app = express();
const PORT = 3002;

mongoose.connect('mongodb://localhost:27017/candy_store', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('✅ Connected to MongoDB (admin)'));

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API to get all menu items
app.get('/api/menu', async (req, res) => {
  const menu = await MenuItem.find();
  res.json(menu);
});

// API to get all orders
app.get('/api/orders', async (req, res) => {
  try {
    const orders = await Order.find();
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch orders.' });
  }
});

// Serve admin.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 Admin server running at http://localhost:${PORT}`);
});
