// server.js
const express = require('express');
const { MongoClient } = require('mongodb');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

// MongoDB connection
const MONGO_URL = 'mongodb://localhost:27017';
const DB_NAME = 'candy_store';
const client = new MongoClient(MONGO_URL);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // Serve frontend

async function startServer() {
  try {
    await client.connect();
    console.log('✅ Connected to MongoDB');

    const db = client.db(DB_NAME);
    const products = db.collection('products');
    const orders = db.collection('orders');

    // GET /products - get all candy products
    app.get('/products', async (req, res) => {
      try {
        const items = await products.find({}).toArray();
        res.json(items);
      } catch (err) {
        res.status(500).json({ message: 'Failed to fetch products' });
      }
    });

    // POST /checkout - place an order
    app.post('/checkout', async (req, res) => {
      const { cart, gcashNumber, address } = req.body;

      if (!cart || !gcashNumber || !address || cart.length === 0) {
        return res.status(400).json({ message: 'Incomplete checkout data' });
      }

      const newOrder = {
        cart,
        gcashNumber,
        address,
        createdAt: new Date(),
      };

      try {
        const result = await orders.insertOne(newOrder);
        res.json({ message: 'Order placed!', orderId: result.insertedId });
      } catch (err) {
        res.status(500).json({ message: 'Failed to save order' });
      }
    });

    app.listen(PORT, () => {
      console.log(`🍬 Candy Store server running at http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('❌ Error starting server:', err);
  }
}

startServer();
