let cart = [];
let total = 0;

fetch('http://localhost:3001/api/products')
  .then(res => res.json())
  .then(products => {
    const menu = document.getElementById('menu');
    products.forEach(product => {
      const item = document.createElement('div');
      item.innerHTML = `
        <img src="${product.image}" width="100"><br>
        <strong>${product.name}</strong><br>
        ₱${product.price}<br>
        <button onclick='addToCart(${JSON.stringify(product)})'>Add to Cart</button>
        <hr>
      `;
      menu.appendChild(item);
    });
  })
  .catch(err => {
    console.error("❌ Failed to load products:", err);
    document.getElementById('menu').innerText = "⚠️ Failed to load menu.";
  });

function addToCart(product) {
  cart.push(product);
  total += product.price;
  const cartItem = document.createElement('li');
  cartItem.textContent = `${product.name} - ₱${product.price}`;
  document.getElementById('cart').appendChild(cartItem);
  document.getElementById('total').innerText = total;
}

function showCheckout() {
  if (cart.length === 0) {
    alert("🛒 Your cart is empty!");
    return;
  }
  document.getElementById('checkout-form').style.display = 'block';
}

function checkout() {
  const gcash = document.getElementById('gcash').value;
  const address = document.getElementById('address').value;

  if (!gcash || !address) {
    alert("⚠️ Please fill in both GCash number and address.");
    return;
  }

  const order = {
    cart,
    total,
    gcash,
    address
  };

  fetch('http://localhost:3001/api/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(order)
  })
    .then(res => res.json())
    .then(response => {
      alert("✅ Order placed successfully!");
      // Reset
      cart = [];
      total = 0;
      document.getElementById('cart').innerHTML = '';
      document.getElementById('total').innerText = 0;
      document.getElementById('gcash').value = '';
      document.getElementById('address').value = '';
      document.getElementById('checkout-form').style.display = 'none';
    })
    .catch(err => {
      console.error(err);
      alert("❌ Failed to place order.");
    });
}
